-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: meucampeonato
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `jogos`
--

DROP TABLE IF EXISTS `jogos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jogos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `chaveamento` json DEFAULT NULL,
  `resultado_quartas` json DEFAULT NULL,
  `chaveamento_semi` json DEFAULT NULL,
  `chaveamento_final` json DEFAULT NULL,
  `chaveamento_terceiro` json DEFAULT NULL,
  `resultado_semi` json DEFAULT NULL,
  `resultado_final` json DEFAULT NULL,
  `resultado_terceiro` json DEFAULT NULL,
  `times_pontos` json DEFAULT NULL,
  `id_campeonato` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_campeonato` (`id_campeonato`),
  CONSTRAINT `jogos_ibfk_1` FOREIGN KEY (`id_campeonato`) REFERENCES `campeonatos` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jogos`
--

LOCK TABLES `jogos` WRITE;
/*!40000 ALTER TABLE `jogos` DISABLE KEYS */;
INSERT INTO `jogos` VALUES (41,'[[{\"id\": 3, \"nome\": \"Palmeiras FC\", \"escudo\": \"uploads/escudo-palmeiras.png\"}, {\"id\": 2, \"nome\": \"Corinthians FC\", \"escudo\": \"uploads/logo-corinthians-1536.png\"}], [{\"id\": 8, \"nome\": \"Botafogo FC\", \"escudo\": \"uploads/R (1).png\"}, {\"id\": 5, \"nome\": \"Flamengo FC\", \"escudo\": \"uploads/R.png\"}], [{\"id\": 1, \"nome\": \"São Paulo FC\", \"escudo\": \"uploads/spfc.png\"}, {\"id\": 6, \"nome\": \"Fluminense FC\", \"escudo\": \"uploads/fluminense-logo-escudo.png\"}], [{\"id\": 4, \"nome\": \"Santos FC\", \"escudo\": \"uploads/santos-logo-escudo-2.png\"}, {\"id\": 7, \"nome\": \"Vasco FC\", \"escudo\": \"uploads/OIP.jpg\"}]]','[{\"time1\": {\"id\": 5, \"nome\": \"Flamengo FC\", \"escudo\": \"uploads/R.png\"}, \"time2\": {\"id\": 1, \"nome\": \"São Paulo FC\", \"escudo\": \"uploads/spfc.png\"}, \"vencedor\": {\"id\": 1, \"nome\": \"São Paulo FC\", \"escudo\": \"uploads/spfc.png\"}, \"golsTime1\": 4, \"golsTime2\": 4, \"golsTotalTime1\": 4, \"golsTotalTime2\": 7, \"golsPenaltisTime1\": 0, \"golsPenaltisTime2\": 3}, {\"time1\": {\"id\": 8, \"nome\": \"Botafogo FC\", \"escudo\": \"uploads/R (1).png\"}, \"time2\": {\"id\": 6, \"nome\": \"Fluminense FC\", \"escudo\": \"uploads/fluminense-logo-escudo.png\"}, \"vencedor\": {\"id\": 6, \"nome\": \"Fluminense FC\", \"escudo\": \"uploads/fluminense-logo-escudo.png\"}, \"golsTime1\": 0, \"golsTime2\": 4, \"golsTotalTime1\": 0, \"golsTotalTime2\": 4, \"golsPenaltisTime1\": 0, \"golsPenaltisTime2\": 0}, {\"time1\": {\"id\": 2, \"nome\": \"Corinthians FC\", \"escudo\": \"uploads/logo-corinthians-1536.png\"}, \"time2\": {\"id\": 3, \"nome\": \"Palmeiras FC\", \"escudo\": \"uploads/escudo-palmeiras.png\"}, \"vencedor\": {\"id\": 2, \"nome\": \"Corinthians FC\", \"escudo\": \"uploads/logo-corinthians-1536.png\"}, \"golsTime1\": 2, \"golsTime2\": 2, \"golsTotalTime1\": 7, \"golsTotalTime2\": 4, \"golsPenaltisTime1\": 5, \"golsPenaltisTime2\": 2}, {\"time1\": {\"id\": 4, \"nome\": \"Santos FC\", \"escudo\": \"uploads/santos-logo-escudo-2.png\"}, \"time2\": {\"id\": 7, \"nome\": \"Vasco FC\", \"escudo\": \"uploads/OIP.jpg\"}, \"vencedor\": {\"id\": 4, \"nome\": \"Santos FC\", \"escudo\": \"uploads/santos-logo-escudo-2.png\"}, \"golsTime1\": 2, \"golsTime2\": 1, \"golsTotalTime1\": 2, \"golsTotalTime2\": 1, \"golsPenaltisTime1\": 0, \"golsPenaltisTime2\": 0}]','[[{\"id\": 1, \"nome\": \"São Paulo FC\", \"escudo\": \"uploads/spfc.png\"}, {\"id\": 6, \"nome\": \"Fluminense FC\", \"escudo\": \"uploads/fluminense-logo-escudo.png\"}], [{\"id\": 2, \"nome\": \"Corinthians FC\", \"escudo\": \"uploads/logo-corinthians-1536.png\"}, {\"id\": 4, \"nome\": \"Santos FC\", \"escudo\": \"uploads/santos-logo-escudo-2.png\"}]]','[[{\"id\": 6, \"nome\": \"Fluminense FC\", \"escudo\": \"uploads/fluminense-logo-escudo.png\"}, {\"id\": 2, \"nome\": \"Corinthians FC\", \"escudo\": \"uploads/logo-corinthians-1536.png\"}]]','[[{\"id\": 1, \"nome\": \"São Paulo FC\", \"escudo\": \"uploads/spfc.png\"}, {\"id\": 4, \"nome\": \"Santos FC\", \"escudo\": \"uploads/santos-logo-escudo-2.png\"}]]','[{\"time1\": {\"id\": 1, \"nome\": \"São Paulo FC\", \"escudo\": \"uploads/spfc.png\"}, \"time2\": {\"id\": 6, \"nome\": \"Fluminense FC\", \"escudo\": \"uploads/fluminense-logo-escudo.png\"}, \"vencedor\": {\"id\": 1, \"nome\": \"São Paulo FC\", \"escudo\": \"uploads/spfc.png\"}, \"golsTime1\": 3, \"golsTime2\": 1, \"golsTotalTime1\": 3, \"golsTotalTime2\": 1, \"golsPenaltisTime1\": 0, \"golsPenaltisTime2\": 0}, {\"time1\": {\"id\": 2, \"nome\": \"Corinthians FC\", \"escudo\": \"uploads/logo-corinthians-1536.png\"}, \"time2\": {\"id\": 4, \"nome\": \"Santos FC\", \"escudo\": \"uploads/santos-logo-escudo-2.png\"}, \"vencedor\": {\"id\": 4, \"nome\": \"Santos FC\", \"escudo\": \"uploads/santos-logo-escudo-2.png\"}, \"golsTime1\": 3, \"golsTime2\": 3, \"golsTotalTime1\": 6, \"golsTotalTime2\": 7, \"golsPenaltisTime1\": 3, \"golsPenaltisTime2\": 4}]','[{\"time1\": {\"id\": 6, \"nome\": \"Fluminense FC\", \"escudo\": \"uploads/fluminense-logo-escudo.png\"}, \"time2\": {\"id\": 2, \"nome\": \"Corinthians FC\", \"escudo\": \"uploads/logo-corinthians-1536.png\"}, \"vencedor\": {\"id\": 2, \"nome\": \"Corinthians FC\", \"escudo\": \"uploads/logo-corinthians-1536.png\"}, \"golsTime1\": 1, \"golsTime2\": 1, \"golsTotalTime1\": 2, \"golsTotalTime2\": 4, \"golsPenaltisTime1\": 1, \"golsPenaltisTime2\": 3}]','[{\"time1\": {\"id\": 1, \"nome\": \"São Paulo FC\", \"escudo\": \"uploads/spfc.png\"}, \"time2\": {\"id\": 4, \"nome\": \"Santos FC\", \"escudo\": \"uploads/santos-logo-escudo-2.png\"}, \"vencedor\": {\"id\": 1, \"nome\": \"São Paulo FC\", \"escudo\": \"uploads/spfc.png\"}, \"golsTime1\": 1, \"golsTime2\": 1, \"golsTotalTime1\": 6, \"golsTotalTime2\": 2, \"golsPenaltisTime1\": 5, \"golsPenaltisTime2\": 1}]','{\"1\": 0, \"4\": 0}',2),(52,'[[{\"id\": 2, \"nome\": \"Corinthians FC\", \"escudo\": \"uploads/logo-corinthians-1536.png\"}, {\"id\": 6, \"nome\": \"Fluminense FC\", \"escudo\": \"uploads/fluminense-logo-escudo.png\"}], [{\"id\": 7, \"nome\": \"Vasco FC\", \"escudo\": \"uploads/OIP.jpg\"}, {\"id\": 3, \"nome\": \"Palmeiras FC\", \"escudo\": \"uploads/escudo-palmeiras.png\"}], [{\"id\": 4, \"nome\": \"Santos FC\", \"escudo\": \"uploads/santos-logo-escudo-2.png\"}, {\"id\": 1, \"nome\": \"São Paulo FC\", \"escudo\": \"uploads/spfc.png\"}], [{\"id\": 8, \"nome\": \"Botafogo FC\", \"escudo\": \"uploads/R (1).png\"}, {\"id\": 9, \"nome\": \"Internacional FC\", \"escudo\": \"uploads/internacional-porto-alegre-logo-escudo-4.png\"}]]','[{\"time1\": {\"id\": 2, \"nome\": \"Corinthians FC\", \"escudo\": \"uploads/logo-corinthians-1536.png\"}, \"time2\": {\"id\": 6, \"nome\": \"Fluminense FC\", \"escudo\": \"uploads/fluminense-logo-escudo.png\"}, \"vencedor\": {\"id\": 2, \"nome\": \"Corinthians FC\", \"escudo\": \"uploads/logo-corinthians-1536.png\"}, \"golsTime1\": 1, \"golsTime2\": 1, \"golsTotalTime1\": 6, \"golsTotalTime2\": 5, \"golsPenaltisTime1\": 5, \"golsPenaltisTime2\": 4}, {\"time1\": {\"id\": 7, \"nome\": \"Vasco FC\", \"escudo\": \"uploads/OIP.jpg\"}, \"time2\": {\"id\": 3, \"nome\": \"Palmeiras FC\", \"escudo\": \"uploads/escudo-palmeiras.png\"}, \"vencedor\": {\"id\": 7, \"nome\": \"Vasco FC\", \"escudo\": \"uploads/OIP.jpg\"}, \"golsTime1\": 3, \"golsTime2\": 2, \"golsTotalTime1\": 3, \"golsTotalTime2\": 2, \"golsPenaltisTime1\": 0, \"golsPenaltisTime2\": 0}, {\"time1\": {\"id\": 4, \"nome\": \"Santos FC\", \"escudo\": \"uploads/santos-logo-escudo-2.png\"}, \"time2\": {\"id\": 1, \"nome\": \"São Paulo FC\", \"escudo\": \"uploads/spfc.png\"}, \"vencedor\": {\"id\": 1, \"nome\": \"São Paulo FC\", \"escudo\": \"uploads/spfc.png\"}, \"golsTime1\": 2, \"golsTime2\": 2, \"golsTotalTime1\": 5, \"golsTotalTime2\": 6, \"golsPenaltisTime1\": 3, \"golsPenaltisTime2\": 4}, {\"time1\": {\"id\": 8, \"nome\": \"Botafogo FC\", \"escudo\": \"uploads/R (1).png\"}, \"time2\": {\"id\": 9, \"nome\": \"Internacional FC\", \"escudo\": \"uploads/internacional-porto-alegre-logo-escudo-4.png\"}, \"vencedor\": {\"id\": 9, \"nome\": \"Internacional FC\", \"escudo\": \"uploads/internacional-porto-alegre-logo-escudo-4.png\"}, \"golsTime1\": 2, \"golsTime2\": 2, \"golsTotalTime1\": 5, \"golsTotalTime2\": 7, \"golsPenaltisTime1\": 3, \"golsPenaltisTime2\": 5}]','[[{\"id\": 2, \"nome\": \"Corinthians FC\", \"escudo\": \"uploads/logo-corinthians-1536.png\"}, {\"id\": 7, \"nome\": \"Vasco FC\", \"escudo\": \"uploads/OIP.jpg\"}], [{\"id\": 1, \"nome\": \"São Paulo FC\", \"escudo\": \"uploads/spfc.png\"}, {\"id\": 9, \"nome\": \"Internacional FC\", \"escudo\": \"uploads/internacional-porto-alegre-logo-escudo-4.png\"}]]','[[{\"id\": 2, \"nome\": \"Corinthians FC\", \"escudo\": \"uploads/logo-corinthians-1536.png\"}, {\"id\": 9, \"nome\": \"Internacional FC\", \"escudo\": \"uploads/internacional-porto-alegre-logo-escudo-4.png\"}]]','[[{\"id\": 7, \"nome\": \"Vasco FC\", \"escudo\": \"uploads/OIP.jpg\"}, {\"id\": 1, \"nome\": \"São Paulo FC\", \"escudo\": \"uploads/spfc.png\"}]]','[{\"time1\": {\"id\": 2, \"nome\": \"Corinthians FC\", \"escudo\": \"uploads/logo-corinthians-1536.png\"}, \"time2\": {\"id\": 7, \"nome\": \"Vasco FC\", \"escudo\": \"uploads/OIP.jpg\"}, \"vencedor\": {\"id\": 7, \"nome\": \"Vasco FC\", \"escudo\": \"uploads/OIP.jpg\"}, \"golsTime1\": 0, \"golsTime2\": 1, \"golsTotalTime1\": 0, \"golsTotalTime2\": 1, \"golsPenaltisTime1\": 0, \"golsPenaltisTime2\": 0}, {\"time1\": {\"id\": 1, \"nome\": \"São Paulo FC\", \"escudo\": \"uploads/spfc.png\"}, \"time2\": {\"id\": 9, \"nome\": \"Internacional FC\", \"escudo\": \"uploads/internacional-porto-alegre-logo-escudo-4.png\"}, \"vencedor\": {\"id\": 1, \"nome\": \"São Paulo FC\", \"escudo\": \"uploads/spfc.png\"}, \"golsTime1\": 0, \"golsTime2\": 0, \"golsTotalTime1\": 4, \"golsTotalTime2\": 3, \"golsPenaltisTime1\": 4, \"golsPenaltisTime2\": 3}]','[{\"time1\": {\"id\": 2, \"nome\": \"Corinthians FC\", \"escudo\": \"uploads/logo-corinthians-1536.png\"}, \"time2\": {\"id\": 9, \"nome\": \"Internacional FC\", \"escudo\": \"uploads/internacional-porto-alegre-logo-escudo-4.png\"}, \"vencedor\": {\"id\": 9, \"nome\": \"Internacional FC\", \"escudo\": \"uploads/internacional-porto-alegre-logo-escudo-4.png\"}, \"golsTime1\": 3, \"golsTime2\": 4, \"golsTotalTime1\": 3, \"golsTotalTime2\": 4, \"golsPenaltisTime1\": 0, \"golsPenaltisTime2\": 0}]','[{\"time1\": {\"id\": 7, \"nome\": \"Vasco FC\", \"escudo\": \"uploads/OIP.jpg\"}, \"time2\": {\"id\": 1, \"nome\": \"São Paulo FC\", \"escudo\": \"uploads/spfc.png\"}, \"vencedor\": {\"id\": 7, \"nome\": \"Vasco FC\", \"escudo\": \"uploads/OIP.jpg\"}, \"golsTime1\": 3, \"golsTime2\": 0, \"golsTotalTime1\": 3, \"golsTotalTime2\": 0, \"golsPenaltisTime1\": 0, \"golsPenaltisTime2\": 0}]','{\"1\": -3, \"7\": 3}',3);
/*!40000 ALTER TABLE `jogos` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-30 14:49:47
